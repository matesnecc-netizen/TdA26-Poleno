package tda.app.app;

public record Course(
        String id,
        String title,
        String description,
        String lecturer
) {}