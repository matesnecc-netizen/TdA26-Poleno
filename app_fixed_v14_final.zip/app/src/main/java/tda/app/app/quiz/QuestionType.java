package tda.app.app.quiz;

public enum QuestionType {
    SINGLE,
    MULTI
}
