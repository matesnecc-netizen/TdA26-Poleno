package tda.app.app.quiz;

public record QuizOption(
        String id,
        String text
) {}
