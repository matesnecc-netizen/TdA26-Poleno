package tda.app.app;

public enum MaterialType {
    FILE, LINK
}
