package tda.app.app.feed;

public enum FeedItemType {
    POST,
    AUTO
}
