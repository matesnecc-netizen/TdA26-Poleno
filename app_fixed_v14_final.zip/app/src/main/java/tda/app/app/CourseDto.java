package tda.app.app;

public record CourseDto(Long id, String name) {}
